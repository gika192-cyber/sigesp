import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Perfil = 'secretario' | 'coordenador' | 'encarregado' | 'campo' | 'administrativo'
export type StatusServico = 'rascunho' | 'em_andamento' | 'concluido' | 'validado' | 'cancelado'
export type FaseFoto = 'antes' | 'durante' | 'depois'

export interface Equipe {
  id: string
  nome: string
  descricao?: string
  area?: string
  cor: string
  icone: string
  ativa: boolean
  criado_em: string
}

export interface Servico {
  id: string
  equipe_id?: string
  tipo_id?: string
  status: StatusServico
  data_servico: string
  descricao?: string
  logradouro?: string
  bairro?: string
  referencia?: string
  latitude?: number
  longitude?: number
  materiais?: string
  equipamentos?: string
  observacoes?: string
  lancado_por?: string
  criado_em: string
  equipes?: Equipe
  tipos_servico?: { nome: string; icone: string; cor: string }
  fotos?: Foto[]
}

export interface Foto {
  id: string
  servico_id: string
  fase: FaseFoto
  url: string
  nome_arquivo?: string
  criado_em: string
}

export interface Usuario {
  id: string
  nome: string
  email: string
  perfil: Perfil
  equipe_id?: string
  ativo: boolean
}

export interface Demanda {
  id: string
  titulo: string
  descricao?: string
  prioridade: 'baixa' | 'media' | 'alta' | 'emergencial'
  status: 'aberta' | 'em_andamento' | 'concluida' | 'cancelada'
  equipe_id?: string
  logradouro?: string
  bairro?: string
  prazo?: string
  criado_em: string
}
