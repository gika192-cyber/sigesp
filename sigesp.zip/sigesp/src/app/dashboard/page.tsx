'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'

export default function DashboardPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({ servicos_hoje: 0, servicos_mes: 0, demandas_abertas: 0, equipes_ativas: 0 })

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) { router.push('/login'); return }

      const hoje = new Date().toISOString().split('T')[0]

      const [{ count: hoje_count }, { count: mes_count }, { count: demandas_count }, { count: equipes_count }] = await Promise.all([
        supabase.from('servicos').select('*', { count: 'exact', head: true }).gte('criado_em', hoje),
        supabase.from('servicos').select('*', { count: 'exact', head: true }).gte('criado_em', new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString()),
        supabase.from('demandas').select('*', { count: 'exact', head: true }).eq('status', 'aberta'),
        supabase.from('equipes').select('*', { count: 'exact', head: true }).eq('ativa', true),
      ])

      setStats({
        servicos_hoje: hoje_count || 0,
        servicos_mes: mes_count || 0,
        demandas_abertas: demandas_count || 0,
        equipes_ativas: equipes_count || 0,
      })
      setLoading(false)
    }
    checkAuth()
  }, [router])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/login')
  }

  if (loading) return (
    <div style={{ minHeight: '100vh', background: '#0d1117', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ color: '#8b949e', fontSize: '14px' }}>Carregando...</div>
    </div>
  )

  const kpis = [
    { label: 'Serviços hoje', value: stats.servicos_hoje, icon: '🔧', cor: '#2f81f7' },
    { label: 'Serviços no mês', value: stats.servicos_mes, icon: '📋', cor: '#3fb950' },
    { label: 'Demandas abertas', value: stats.demandas_abertas, icon: '⚠️', cor: '#d29922' },
    { label: 'Equipes ativas', value: stats.equipes_ativas, icon: '👥', cor: '#a371f7' },
  ]

  return (
    <div style={{ minHeight: '100vh', background: '#0d1117', fontFamily: "'DM Sans', system-ui, sans-serif" }}>
      {/* Topbar */}
      <div style={{ background: '#161b22', borderBottom: '1px solid rgba(255,255,255,0.07)', padding: '0 24px', height: '56px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ width: '32px', height: '32px', background: 'linear-gradient(135deg, #2f81f7, #a371f7)', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '800', fontSize: '12px', color: 'white' }}>SG</div>
          <span style={{ color: '#e6edf3', fontWeight: '700', fontSize: '15px' }}>SIGESP</span>
          <span style={{ color: '#6e7681', fontSize: '13px' }}>· Dashboard</span>
        </div>
        <button onClick={handleLogout} style={{ background: 'transparent', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '6px', color: '#8b949e', padding: '6px 14px', cursor: 'pointer', fontSize: '13px' }}>
          Sair
        </button>
      </div>

      {/* Conteúdo */}
      <div style={{ padding: '32px 24px', maxWidth: '1100px', margin: '0 auto' }}>
        <div style={{ marginBottom: '32px' }}>
          <h1 style={{ color: '#e6edf3', fontSize: '22px', fontWeight: '700', marginBottom: '4px' }}>Painel Geral</h1>
          <p style={{ color: '#8b949e', fontSize: '13px' }}>Secretaria de Infraestrutura · Castro Alves BA</p>
        </div>

        {/* KPIs */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '14px', marginBottom: '32px' }}>
          {kpis.map((kpi, i) => (
            <div key={i} style={{ background: '#161b22', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '12px', padding: '20px', borderBottom: `3px solid ${kpi.cor}` }}>
              <div style={{ fontSize: '24px', marginBottom: '12px' }}>{kpi.icon}</div>
              <div style={{ fontSize: '36px', fontWeight: '800', color: '#e6edf3', lineHeight: 1, marginBottom: '6px' }}>{kpi.value}</div>
              <div style={{ fontSize: '13px', color: '#8b949e' }}>{kpi.label}</div>
            </div>
          ))}
        </div>

        {/* Ações rápidas */}
        <div style={{ background: '#161b22', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '12px', padding: '24px' }}>
          <p style={{ color: '#e6edf3', fontWeight: '600', fontSize: '15px', marginBottom: '16px' }}>Ações Rápidas</p>
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            {[
              { label: '+ Novo Serviço', cor: '#2f81f7' },
              { label: '+ Nova Demanda', cor: '#d29922' },
              { label: '👥 Equipes', cor: '#3fb950' },
              { label: '📄 Relatórios', cor: '#a371f7' },
            ].map((btn, i) => (
              <button key={i} style={{ background: 'transparent', border: `1px solid ${btn.cor}`, borderRadius: '8px', color: btn.cor, padding: '10px 20px', cursor: 'pointer', fontSize: '14px', fontWeight: '500', fontFamily: "'DM Sans', sans-serif" }}>
                {btn.label}
              </button>
            ))}
          </div>
        </div>

        <p style={{ color: '#6e7681', fontSize: '12px', textAlign: 'center', marginTop: '48px' }}>
          SIGESP v1.0 · Sistema funcionando ✓
        </p>
      </div>
    </div>
  )
}
