/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['dcpbzqdbsdtdljmbgxrt.supabase.co'],
  },
}
module.exports = nextConfig
